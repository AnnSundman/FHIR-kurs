# fhir.education.kursig#0.1.0: Anns test

## Pages

* [Hem](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Education Patient](StructureDefinition-EducationPatient.md)

### ImplementationGuides

* [Anns test](index.md)

### Examples

* [patient-tolvan (Patient)](Patient-patient-tolvan.md)
